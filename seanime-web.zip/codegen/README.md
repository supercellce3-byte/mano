# Codegen

Run after adding/removing/updating:
- A struct returned by a route handler.
- A route handler.
- A route endpoint.

Code is generated in the `./codegen` directory and in `../seanime-web/src/api/generated`.

Make sure the web codebase is up-to-date after running this script.
