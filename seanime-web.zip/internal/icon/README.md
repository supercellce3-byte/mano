## Windows

```bash
make_icon.bat iconwin.ico
```

## UNIX

```bash
sh make_icon.sh icon.png
```
