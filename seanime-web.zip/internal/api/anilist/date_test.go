package anilist

//import (

//)
//
//func TestFuzzyDate(t *testing.T) {
//
//	date := "2006-01-02T15:04:05Z"
//
//	parsedDate, err := time.Parse(time.RFC3339, date)
//	if err != nil {
//		t.Fatal(err)
//	}
//
//	year := parsedDate.Year()
//	month := int(parsedDate.Month())
//	day := parsedDate.Day()
//	t.Logf("Year: %d, Month: %d, Day: %d", year, month, day)
//
//}
//
//func TestDateTransformation(t *testing.T) {
//
//	t.Logf(time.Date(2024, time.Month(1), 1, 0, 0, 0, 0, time.Local).UTC().Format(time.RFC3339))
//
//}
