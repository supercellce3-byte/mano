The transcoder implementation was adapted from [zoriya/Kyoo](https://github.com/zoriya/Kyoo/tree/master/transcoder),
licensed under GPL-3.0.
