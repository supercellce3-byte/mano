package hibikextension

type (
	SelectOption struct {
		Value string `json:"value"`
		Label string `json:"label"`
	}
)
