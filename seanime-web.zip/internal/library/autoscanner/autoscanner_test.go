package autoscanner

import (
	"testing"
)

func TestAutoScanner(t *testing.T) {

}
