# anime

This package contains structs that represent the main data structures of the local anime library.
Such as `LocalFile` and `LibraryEntry`.

### 🚫 Do not

- Do not import **database**.
