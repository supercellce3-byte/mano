Full credit to [thelennylord/discord-rpc](https://github.com/thelennylord/discord-rpc/)
