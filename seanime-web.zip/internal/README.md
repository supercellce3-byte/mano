<p align="center">
<img src="../docs/images/seanime-logo.png" alt="preview" width="70px"/>
</p>

<h2 align="center"><b>Seanime Server</b></h2>
