# Matroska Parser

Based on `github.com/luispater/matroska-go` (MIT)

## Features

- No CGO, no dependencies
- Works with seekable (io.ReadSeeker) and non-seekable (io.Reader) streams
- Can start parsing mid-stream
