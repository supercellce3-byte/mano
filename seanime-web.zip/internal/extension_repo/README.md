## Add packages to Go interpreter

1. Extract package symbols using `yaegi` CLI tool

	```bash
	cd internal/yaegi_interp
	```
	
	```bash
	yaegi extract "github.com/5rahim/hibike/a/b"
	yaegi extract "github.com/a/b/c"
	```
