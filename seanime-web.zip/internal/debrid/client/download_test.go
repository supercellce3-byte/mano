package debrid_client

import (
	"seanime/internal/test_utils"
	"testing"
)

func TestDownload(t *testing.T) {
	test_utils.InitTestProvider(t)

}
